/*
 ============================================================================
 Name        : serverUDP.c
 Author      : Rossella
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "server_client.h"

#define handle_error(msg) \
		do { perror(msg); exit(EXIT_FAILURE); } while (0)

//Method for clear the socket
void clearwinsock(int s) {
#if defined WIN32
	WSACleanup();
#endif
}




int add(int a, int b){
	return a + b;
}
int mult(int a, int b){
	return a*b;
}
int sub(int a, int b){
	return a-b;
}
void division(int a, int b, char* result){
	gcvt((a/b), 10, result);
}

void processMSGClient(struct MSGClient msgClient, char* output){
	switch(msgClient.operation){
	case '+':
		itoa(add(msgClient.number1, msgClient.number2), output, 10);
		break;

	case '-':
		itoa(sub(msgClient.number1, msgClient.number2), output, 10);
		break;

	case 'x':
		itoa(mult(msgClient.number1, msgClient.number2), output, 10);
		break;

	case '/':
		division(msgClient.number1, msgClient.number2, output);
		break;
	case '=':
		strcpy(output, "exit");
		break;
	}
}


int main(int argc, char *argv[]){

#if defined WIN32
	//initialaizing WinSock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);

	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		fflush(stdout);
		system("pause");
		return -1;
	}

#endif

	int sockFileDescr = 0, clientlen = 0;
	struct sockaddr_in server;
	struct sockaddr_in client;
	struct MSGClient msgClient;

	//Create a socket and save his descriptor
	sockFileDescr = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP); //socket descriptor

	if (sockFileDescr == SOCKETERROR) {
		printf("socket creation failed.\n");
		closesocket(sockFileDescr);
		clearwinsock(sockFileDescr);

		system("pause");
		return -1;
	}

	//initialaizing server IP
	memset((void *) &server, 0, sizeof(server)); // reset IP server
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(INADDR_SOCKET); // INADDR_ANY = Constant, IP host
	server.sin_port = htons(PORT); // PORT = Constant, number of port

	printf("Server address: %lu \n", inet_addr(INADDR_SOCKET));
	fflush(stdout);

	// binding of IP and transport end point (socket file descriptor)
	if (bind(sockFileDescr, (struct sockaddr *) &server, sizeof(server)) < 0){
		handle_error("bind() failed.");
		clearwinsock(sockFileDescr);
		system("pause");
		return -1;
	}

	clientlen = sizeof(client);

	printf("The server is on!");

	// managment of client connection
	while (1) {
		printf("\nWaiting for a massage... \n");
		fflush(stdout);

		//set the size of the client address
		//clientAddLen = sizeof(client);

		//clientSocket is connected to a client
		//inet_ntoa() convert a number of 32 bit to a number in dot notation

		while(1){
			//receve a message task to execute or an exit message.

			recvfrom(sockFileDescr, (void *) &msgClient, sizeof(msgClient), 0, (struct sockaddr *) &client, &clientlen);

			if (server.sin_addr.s_addr != client.sin_addr.s_addr){
				printf("\nError: received a packet from unknown source.\n");
				system("pause"); return -1;

			}

			system("cls");
			printf( "\nMessage received form client ip:%s  port:%d", inet_ntoa(client.sin_addr), client.sin_port );

			char replyToSend[] = "";
			processMSGClient(msgClient, replyToSend);

			//exit if client request to close connection
			if(strcmp(replyToSend, "exit") == 0){
				break;
			}

			//send the result of the task execution
			if (sendto(sockFileDescr, replyToSend, strlen(replyToSend), 0, (struct sockaddr *) &client, clientlen) != strlen(replyToSend)) {
				printf("\nsendto() sent different number of bytes than expected\n");
				fflush(stdout);
				clearwinsock(sockFileDescr);
				system("pause");
				return -1;
			}

			printf("\nResult sent to ip:%s  port:%d", inet_ntoa(client.sin_addr), client.sin_port );


		}
		printf( "\nDisconnected from client %s:%d \n", inet_ntoa(client.sin_addr), client.sin_port );
	}// end of the while loop


	system("pause");
	return 0;
}

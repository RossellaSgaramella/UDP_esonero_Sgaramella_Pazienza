#ifndef SERVER_CLIENT_H_
#define SERVER_CLIENT_H_

#ifdef WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#define PORT 50000
#define NO_ERROR 0
#define SOCKETERROR -1
#define INADDR_SOCKET "127.0.0.1"
#define BUFFERSIZE 512


typedef struct MSGClient{
	char operation;
	int number1;
	int number2;
}MSGClient;

#endif

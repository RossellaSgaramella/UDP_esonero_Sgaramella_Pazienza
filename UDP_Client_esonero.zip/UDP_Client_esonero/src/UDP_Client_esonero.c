/*
 ============================================================================
 Name        : clientUDP.c
 Author      : Rossella
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>

#include "server_client.h"

//error message
void errorHandler(char *errorMessage) {
	printf("%s",errorMessage);
	fflush(stdout);
}

//check that a string is a number
int isInteger(char *string){
	int flag = 0;
	for(int i = 0; i < strlen(string)-1; i++){
		if(!isdigit(string[i])){
			flag = 1;
		}
	}
	return flag;
}




void clearWinSock() {
#if defined WIN32
	WSACleanup();
#endif
}



int main(int argc,char *argv[]){

#if defined WIN32
	WSADATA wsaData;// Create an element WSADATA type,that is a struct that contain
	//informations about implementation of socket on windows

	int iResult = WSAStartup(MAKEWORD(2 ,2), &wsaData);// specify the version of windows socket required and recover the details of implementation about windows socket specified

	//check for errors
	if (iResult != 0) {
		printf ("error at WSASturtup\n");
		fflush(stdout);
		system("pause"); return -1;
	}

#endif

	char portServerString[10] = "";
	char nameServerStringTemp[40] = "";
	char nameServer[100];
	int portNumber = 0;
	int p = 0, n = 0, serverLen = 0;

	if (argc == 2){
		for (int i = 0; i < strlen(argv[0]); i++){
			if(argv[1][i] == ' ' || argv[1][i] == '\0'){
				break;
			}
			if(argv[1][i] == ':' || p != 0){
				portServerString[p] = argv[1][i];
				p++;
			}
			else{
				nameServerStringTemp[n] = argv[1][i];
				n++;
			}
			//remove spaces
			for (int i = 0; i < n; i++){
				nameServer[i] = nameServerStringTemp[i];
			}

			//convert the input port into ad integer
			if(isInteger(portServerString) == 0){
				portNumber = atoi(portServerString);
			}
		}
	}
	else if (argc > 2){
		printf("Param insert are too much!\n ");
		system("pause");
		system("pause"); return -1;
	}
	else{
		strcpy(nameServer, SERVER_NAME_DEFAULT);
		portNumber = PORT;
	}

	//  SOCKET CREATION
	int mySocket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP); //socket descriptor

	//check that the socket is valid
	if(mySocket < 0){
		errorHandler("Socket creation failed\n");
		fflush(stdout);
		closesocket(mySocket);
		clearWinSock();
		system("pause");
		return -1;
	}


	printf("\n-------------------WELCOME-----------------------\n");

	// CONSTRUCTION OF THE SERVER ADDRESS
	struct hostent *host;
	struct in_addr* ina;
	struct sockaddr_in sad, fromAddr;

	host = gethostbyname(nameServer);
	if(host == NULL){
		printf("Cant get host by name!\n");
		system("pause");
		return -1;
	}

	//getting ipAddres from name host
	ina = (struct in_addr*) host->h_addr_list[0];
	printf("Risultato di gethostbyname(%s): %s\n", nameServer, inet_ntoa(*ina));


	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET;
	sad.sin_addr = *ina; // IP del server
	sad.sin_port = htons(portNumber); // Server port

	serverLen = sizeof(sad);

	printf("\nConnected to Server %s\n", inet_ntoa(sad.sin_addr)); // print Server IP
	printf("-------------------------------------------------\n");
	fflush(stdout);

	//in case of success I get the success message from the server
	char buffer[BUFFERSIZE]={'\0'};

	MSGClient msgClient;

	printf("\nInsert '=' to terminate the client or '[operation] (space) [number] (space) [number]'");
	printf("\n\nPlease, use the operation character as '+' or '-' or 'x' or '/'\n");

	//SENDING AND RECEIVING THE MESSAGE

	while(1){
		char command[100];
		msgClient.operation = ' ';
		msgClient.number1 = 0;
		msgClient.number2 = 0;


		printf("\nEnter the command->");
		fflush(stdout);
		fgets(command, 255, stdin);


		if(command[0] !='='){
			char operator1[10] = "";
			char operator2[10] = "";
			int i=1, a=0, b=0;


			if(command[0] != '+' && command[0] != '-' && command[0] != 'x' && command[0] != '/'){
				printf("\nCommand entered incorrect!");
				fflush(stdout);
			}
			else{
				msgClient.operation = command[0];

				for(i=2; i<strlen(command) && command[i] != ' '; i++){
					if(command[i] != ' '){
						operator1[a] = command[i];
						a++;
					}
				}

				int j=i+1;

				for(j=i+1; j<strlen(command) && command[j] != '\0'; j++){
					operator2[b] = command[j];
					b++;
				}
				msgClient.number1 = atoi(operator1);
				msgClient.number2 = atoi(operator2);

				if(msgClient.operation == '/' && msgClient.number2 == 0){
					printf("\nDivision from 0 is not possible, try with a different divider");
				}
				else{


					if (sendto(mySocket, (void *) &msgClient, sizeof(msgClient), 0, (struct sockaddr*)&sad, serverLen) != sizeof(msgClient)){
						printf("sendto() sent different number of bytes than expected");
						system("pause");
						return -1;
					}
					int fromSize = sizeof(fromAddr);
					recvfrom(mySocket, buffer, BUFFERSIZE, 0, (struct sockaddr*)&fromAddr, &fromSize);

					if (sad.sin_addr.s_addr != fromAddr.sin_addr.s_addr){
						printf("Error: received a packet from unknown source.\n");
						system("pause");
						return -1;

					}

					else{
						printf("Result message get from %s, ip %s: %d %c %d = %s", nameServer, inet_ntoa(sad.sin_addr), msgClient.number1, msgClient.operation, msgClient.number2, buffer);
						fflush(stdout);
					}
				}
			}
		}else{
			msgClient.operation = '=';
			msgClient.number1 = 0;
			msgClient.number2 = 0;

			if (sendto(mySocket, (void *) &msgClient, sizeof(msgClient), 0, (struct sockaddr*)&sad, sizeof(sad)) != sizeof(msgClient)){
				printf("sendto() sent different number of bytes than expected");
				system("pause");
				return -1;
			}
			// CLOSING THE CONNECTION
			closesocket(mySocket);
			clearWinSock();
			printf("\n"); // Print a final linefeed
			fflush(stdout);
			printf("\nSee you soon\n");
			fflush(stdout);
			system("pause");
			return -1;
		}
		printf("\n");
		system("pause");
		system("cls");
	}


	system("pause");
	return 0;
}
